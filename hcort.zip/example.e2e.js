
const jsonfile = require('jsonfile')
 
const file = 'casestatus.json'

describe('My Login application', () => {
    it('should login with valid credentials', async () => {
      for( let i=96;i<150;i++)
      {
        await browser.url(`https://nopecha.com/setup#t30ja9cqhyxklebd`)
       await browser.url(`https://hcservices.ecourts.gov.in/ecourtindiaHC/cases/case_no.php?state_cd=11&dist_cd=1&court_code=1&stateNm=Odisha/`)
       await  browser.maximizeWindow()
       await browser.pause(10000);

       await browser.pause(3000);
     await $("//select[@id='case_type']").click();
     await browser.pause(3000);
     await $("//option[contains(text(),'BLAPL - BLAPL-Bail Application.(7)')]").click();
     await browser.pause(3000);

     await $("//input[@id='rgyear']").setValue('2022');
     await browser.pause(3000);

     await $("//input[@id='search_case_no']").setValue(i);
     await $("[value='Go']").click();
     await browser.pause(8000);
     await $("//a[contains(text(),'View')]").click();
     await browser.pause(8000);
     var name = await $("[class='Petitioner_Advocate_table']").getText();
     var advindex  = await name.indexOf("Advocate");
     var nam = await name.slice(advindex);
      var allowed = await $("span:nth-child(7) label:nth-child(1) > strong:nth-child(2)").getText();
    if(allowed.includes("Allowed"))  
    {
      var won = "won"; 
    }
    else 
    var won = "lost";
    
    const obj = {CaseNo: i, AdvocateName:nam, CaseStatus: won};
    jsonfile.writeFile(file, obj, { flag: 'a' }, function (err) {
      if (err) console.error(err)
    })
    // await  exTest(i,nam,won);
   
  }


  //  })

})
})
// async function exTest(nos,nam,won){
 

// worksheet.columns = [
//  {caseno: 'No', key: 'no', width: 10},
//  {AdvocateName: 'Name', key: 'name', width: 32}, 
//  {allowedoornot: 'Status', key: 'status', width: 15,}
// ];

// worksheet.addRow({no: nos, name: nam, status: won});
// worksheet.addRow({id: 2, name: 'Jane Doe', dob: new Date(1965, 1, 7)});

// save under export.xlsx




